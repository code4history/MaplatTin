import { generatedCases, quantizationSurvey, duplicateInsertionProbe } from './tests/edge-nodes-generated-cases.ts';
import fs from 'node:fs';
const seed=Number(process.env.EDGE_SEED??20261128), count=Number(process.env.EDGE_CASES??200);
const cases=generatedCases(seed,count),failures=[];
for(const c of cases) { try{c.run();}catch(e){failures.push({name:c.name,error:String(e)});} }
let duplicateProbe;
try{duplicateInsertionProbe();duplicateProbe='passed';}catch(e){duplicateProbe=String(e);}
const survey=quantizationSurvey();
const result={runtime:process.version,seed,count,total:cases.length,passed:cases.length-failures.length,failures,duplicateProbe,survey};
fs.writeFileSync('core-results.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,survey:`${survey.length} diagnostic records`},null,2));
process.exitCode=failures.length?1:0;
