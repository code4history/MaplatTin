import fs from 'node:fs';
import { interpolateEdgeNodes as f,edgeNodeMatchTolerance as tol } from './src/edge-nodes.ts';
const results=JSON.parse(fs.readFileSync('core-results.json'));
console.log(results.failures.map(f=>({name:f.name,error:f.error.split('\n').slice(1).join(' ')})));
let {a,b}=JSON.parse(results.failures[0].error.split('\n')[0].slice(7));
function bad(a,b){return f(a,b).length!==a.length-2 || f([...a].reverse(),[...b].reverse()).length!==a.length-2;}
let changed=true;
while(changed){changed=false;for(let i=1;i<a.length-1;i++){const aa=a.filter((_,j)=>i!==j),bb=b.filter((_,j)=>i!==j);if(bad(aa,bb)){a=aa;b=bb;changed=true;break;}}}
function r(ps){const acc=[0];for(let i=1;i<ps.length;i++)acc.push(acc.at(-1)+Math.hypot(ps[i][0]-ps[i-1][0],ps[i][1]-ps[i-1][1]));return acc.map(x=>x/acc.at(-1));}
const ra=r(a),rb=r(b);
const reduced={source:results.failures[0].name,a,b,tolerance:tol(a,b),drift:Math.max(...ra.map((v,i)=>Math.abs(v-rb[i]))),expected:a.length-2,forward:f(a,b),reverse:f([...a].reverse(),[...b].reverse())};
fs.writeFileSync('reduced-counterexample.json',JSON.stringify(reduced,null,2));
console.log(JSON.stringify(reduced,null,2));
