import assert from 'node:assert/strict';
import { interpolateEdgeNodes as interpolate } from '../src/edge-nodes.ts';

type P = number[];
type Case = { name: string; run: () => void };
const E = Number.EPSILON;
function rng(seed: number) {
  return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
}
function similarity(p: P, s: number, theta: number, tx: number, ty: number): P {
  const c = Math.cos(theta), d = Math.sin(theta);
  return [tx + s * (c * p[0] - d * p[1]), ty + s * (d * p[0] + c * p[1])];
}
function ratios(a: P[]) {
  const acc = [0];
  for (let i = 1; i < a.length; i++) acc.push(acc[i-1] + Math.hypot(a[i][0]-a[i-1][0], a[i][1]-a[i-1][1]));
  return acc.map(x => x / acc.at(-1)!);
}
function basic(a: P[], b: P[]) {
  const before = JSON.stringify([a,b]);
  const out = interpolate(a,b);
  assert.equal(JSON.stringify([a,b]), before, 'input mutated');
  assert.ok(out.length <= a.length + b.length - 4);
  out.forEach((n,i) => {
    assert.ok([...n[0],...n[1],n[2]].every(Number.isFinite), 'nonfinite output');
    assert.ok(n[2] >= 0 && n[2] <= 1);
    if (i) assert.ok(out[i-1][2] <= n[2], 'ratio order');
  });
  return out;
}
function context(name: string, a: P[], b: P[], f: () => void) {
  try { f(); } catch (e) { throw new Error(JSON.stringify({name,a,b}) + '\n' + String(e)); }
}

// No DP implementation copied: enumerate all increasing matchings (<= 6 x 6).
// x coordinates are exact integer multiples of EPS, and length is exactly 1.
function optimum(a: number[], b: number[]) {
  let bestCount = -1, bestCost = Infinity;
  function visit(i: number, j: number, count: number, cost: number) {
    if (count > bestCount || (count === bestCount && cost < bestCost)) {
      bestCount = count; bestCost = cost;
    }
    for (let x=i; x<a.length; x++) for (let y=j; y<b.length; y++) {
      const d = Math.abs(a[x]-b[y]);
      if (d <= 264) visit(x+1,y+1,count+1,cost+d);
    }
  }
  visit(0,0,0,0);
  return [bestCount,bestCost];
}
function checkMatching(a: P[], b: P[]) {
  const out = basic(a,b);
  // Source references distinguish selected pairs from interpolated points.
  const pairs = out.map(n => [a.indexOf(n[0]),b.indexOf(n[1])]).filter(([i,j])=> i>0 && j>0);
  for(let k=1;k<pairs.length;k++) {
    assert.ok(pairs[k-1][0]<pairs[k][0] && pairs[k-1][1]<pairs[k][1], 'crossing matches');
  }
  const ticks = (ps: P[])=>ps.slice(1,-1).map(p=>p[0]/E);
  const expected = optimum(ticks(a),ticks(b));
  const cost = pairs.reduce((sum,[i,j])=>sum+Math.abs(a[i][0]/E-b[j][0]/E),0);
  assert.deepEqual([pairs.length,cost],expected,'maximum cardinality / minimum cost');
  // Whole emitted path, including interpolated nodes, must progress on BOTH axes.
  for(let k=1;k<out.length;k++) for(const side of [0,1] as const) {
    assert.ok(out[k-1][side][0] <= out[k][side][0], 'output path reverses');
  }
}
export function generatedCases(seed=20261128, count=200): Case[] {
  const random = rng(seed), cases: Case[] = [];
  for(let c=0;c<count;c++) {
    const ticks = () => Array.from(new Set(Array.from({length:1+Math.floor(random()*6)},()=>Math.floor(random()*1800)-900))).sort((a,b)=>a-b);
    const make = (xs:number[]):P[]=>[[0,0],...xs.map(x=>[0.5+x*E,0]),[1,0]];
    const a=make(ticks()),b=make(ticks());
    const name=`DP seed=${seed} case=${c}`;
    cases.push({name,run:()=>context(name,a,b,()=>{
      checkMatching(a,b);
      checkMatching(b,a); // swaps objective, not tie-break identity
      checkMatching([...a].reverse().map(p=>[1-p[0],0]),[...b].reverse().map(p=>[1-p[0],0]));
    })});
  }
  // Known correspondences from construction, independent of matching tolerance.
  // Monotone-x polyline; no collapsed vertices; broad separation between bends.
  for(let c=0;c<count;c++) {
    const n=c % 100 === 0 ? [121,122,123,256][Math.floor(c/100)%4] : 2+Math.floor(random()*20);
    const base:P[]=Array.from({length:n+2},(_,i)=>[i/(n+1),random()*0.12]);
    const len=[0.5,3,20,1000][c%4];
    const a=base.map(p=>similarity(p,len,0,8000,8000));
    const angle=random()*2*Math.PI;
    const scale=[0.25,50,100,150,1024][c%5];
    const origin=[0,2**24-1,2**24,-(2**24),1.5e7][c%5];
    const b=base.map(p=>similarity(p,len*scale,angle,origin,-origin));
    const name=`similarity seed=${seed} case=${c} len=${len} scale=${scale} angle=${angle}`;
    cases.push({name,run:()=>context(name,a,b,()=>{
      for(const [aa,bb] of [[a,b],[b,a],[[...a].reverse(),[...b].reverse()]] as [P[],P[]][]) {
        const out=basic(aa,bb);
        assert.equal(out.length,n,'split or lost intended bend');
        out.forEach((v,i)=>{assert.deepEqual(v[0],aa[i+1]);assert.deepEqual(v[1],bb[i+1]);});
      }
    })});
  }
  // Separate source bend sets: exact dyadic geometry, unique ordered union oracle.
  for(const shift of [0,2**24,-(2**24)]) for(const scale of [2**-8,1,2**8]) for(const quarter of [0,1,2,3]) {
    const rotate=(p:P):P=>quarter===0?p:quarter===1?[-p[1],p[0]]:quarter===2?[-p[0],-p[1]]:[p[1],-p[0]];
    const t=(x:number):P=>{const p=rotate([scale*x,0]);return [shift+p[0] || 0,-shift+p[1] || 0];};
    const ax=[0,1/8,1/2,1], bx=[0,1/4,3/4,1], union=[1/8,1/4,1/2,3/4];
    const a=ax.map(t),b=bx.map(t);
    const name=`exact union shift=${shift} scale=${scale} quarter=${quarter}`;
    cases.push({name,run:()=>context(name,a,b,()=>{
      const out=basic(a,b);
      assert.equal(out.length,union.length);
      out.forEach((v,i)=>{assert.deepEqual(v[0],t(union[i]));assert.deepEqual(v[1],t(union[i]));assert.equal(v[2],union[i]);});
      const reverse=basic([...a].reverse(),[...b].reverse());
      reverse.forEach((v,i)=>{const j=out.length-1-i;assert.deepEqual(v.slice(0,2),out[j].slice(0,2));assert.equal(v[2],1-out[j][2]);});
    })});
  }
  return cases;
}

// Diagnostic campaign: do NOT demand preservation of unknowable pre-rounding identities.
// Record representable-point collisions separately from algorithmic output collisions.
export function quantizationSurvey() {
  const findings: unknown[]=[];
  for(const origin of [0,1.5e7,2**24,-(2**24)]) for(const length of [1,2**-10,2**-20]) {
    for(const exponent of [10,20,30,40,50]) for(const partner of ["bends", "endpoints"] as const) {
      const d=2**-exponent;
      const a:P[]=[[0,0],[0.5,0],[0.5+d,d],[1,0]];
      const full=a.map(p=>[origin+length*p[0],origin+length*p[1]]);
      const b=partner === "bends" ? full : [full[0], full.at(-1)!];
      const out=basic(a,b);
      const same=(p:P,q:P)=>p[0]===q[0]&&p[1]===q[1];
      const inputCollision=b.some((p,i)=>i>0&&same(p,b[i-1]));
      const collisions=out.slice(1).filter((p,i)=>same(p[0],out[i][0])||same(p[1],out[i][1])).length;
      const endpointCollision=out.some(p=>same(p[0],a[0])||same(p[0],a.at(-1)!)||same(p[1],b[0])||same(p[1],b.at(-1)!));
      if(inputCollision||collisions||endpointCollision||out.length!==2) findings.push({origin,length,exponent,partner,inputCollision,collisions,endpointCollision,count:out.length,a,b,out,ratios:[ratios(a),ratios(b)]});
    }
  }
  return findings;
}
// Proposed contract, not established current API behavior: quotient out a duplicate
// internal point present on BOTH sides. Kept opt-in because currently fails.
export function duplicateInsertionProbe() {
  const a:P[]=[[0,0],[0.5,0],[1,0]];
  const b:P[]=[[0,0],[0.5,0],[1,0]];
  const duplicatedA=[a[0],a[1],[...a[1]],a[2]], duplicatedB=[b[0],b[1],[...b[1]],b[2]];
  assert.deepEqual(interpolate(duplicatedA,duplicatedB),interpolate(a,b));
}
