import { describe, it, expect } from 'vitest';
import { Tin } from '../src/index.ts';
import type { Position } from 'geojson';

// All paper points remain within wh; transform EVERY GCP and bend on the geographic side.
// A monotone-x edge inside an enclosing quadrilateral is a noncrossing PSLG.
const scenarios = Array.from({length:24},(_,i)=>({
  i, scale:[0.25,50,150][i%3], theta:(i*0.731)% (2*Math.PI),
  origin:[0,1.5e7,2**24,-(2**24)][i%4],
  length:[0.5,3,20,100][i%4],
}));
function verify(tin:Tin) {
  expect(tin.tins?.forw?.features.length).toBeGreaterThan(0);
  expect(tin.tins?.bakw?.features.length).toBeGreaterThan(0);
  for(const side of ['forw','bakw'] as const) {
    const triangles=tin.tins![side]!.features;
    const keys=new Set<string>();
    for(const tri of triangles) {
      const ids=(['a','b','c'] as const).map(k=>String(tri.properties![k].index));
      for(const [i,j] of [[0,1],[1,2],[2,0]]) keys.add([ids[i],ids[j]].sort().join('-'));
      const ring=tri.geometry.coordinates[0];
      expect(ring.flat().every(Number.isFinite)).toBe(true);
      const [a,b,c]=ring;
      // Difference products avoid large absolute-coordinate shoelace cancellation.
      const area=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
      expect(Number.isFinite(area)).toBe(true);
      expect(Math.abs(area)).toBeGreaterThan(0);
    }
    for(const edge of tin.pointsSet!.edges) {
      const ids=edge.map(i=>String(tin.pointsSet!.forw.features[i].properties!.target.index));
      expect(keys.has(ids.sort().join('-'))).toBe(true);
    }
  }
}
describe('generated short constrained edges: V2/V3 integration',()=>{
  for(const useV2Algorithm of [true,false]) for(const c of scenarios) for(const reverse of [false,true]) {
    it(`v2=${useV2Algorithm} case=${c.i} reverse=${reverse}`,()=>{
      const map=(p:Position):Position=>[
        c.origin+c.scale*(Math.cos(c.theta)*p[0]-Math.sin(c.theta)*p[1]),
        -c.origin+c.scale*(Math.sin(c.theta)*p[0]+Math.cos(c.theta)*p[1]),
      ];
      const path:Position[]=Array.from({length:7},(_,j)=>[8000+c.length*j/6,8000+c.length*(j%2)*0.06]);
      const gcps:Position[]=[[1000,1000],[15000,1100],[14800,15000],[1200,14800],path[0],path.at(-1)!];
      const tin=new Tin({wh:[16000,16000],stateFull:false,useV2Algorithm,strictMode:Tin.MODE_STRICT});
      tin.setPoints(gcps.map(p=>[p,map(p)]));
      const bends=path.slice(1,-1);
      tin.setEdges([[reverse?[...bends].reverse():bends, (reverse?[...bends].reverse():bends).map(map),reverse?[5,4]:[4,5]]]);
      tin.updateTin();
      expect(tin.edgeNodes!.length).toBe(bends.length);
      verify(tin);
    });
  }
});
