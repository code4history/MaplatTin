import { describe, it, expect } from 'vitest';
import { writeFileSync } from 'node:fs';
import { generatedCases, quantizationSurvey, duplicateInsertionProbe } from './edge-nodes-generated-cases.ts';

const seed=Number(process.env.EDGE_SEED ?? 20261128);
const count=Number(process.env.EDGE_CASES ?? 200);
if (!Number.isSafeInteger(seed) || !Number.isSafeInteger(count) || count < 1 || count > 100000) {
  throw new Error('EDGE_SEED must be an integer; EDGE_CASES must be in 1..100000');
}
describe('generated edge-node contracts',()=>{
  for(const c of generatedCases(seed,count)) it(c.name,c.run);
});
it('quantization survey (diagnostic; a report is NOT a success guarantee)',()=>{
  const records=quantizationSurvey();
  expect(Array.isArray(records)).toBe(true);
  if(process.env.EDGE_REPORT) writeFileSync(process.env.EDGE_REPORT,JSON.stringify({seed,records},null,2));
});
// Explicit opt-in: desired duplicate normalization contract, currently fails.
// Do not use it.fails(), which would turn an implementation defect into a green test.
it.skipIf(process.env.EDGE_PROBE !== '1')('duplicate insertion on both sides should not duplicate an intermediate vertex (proposed contract)',duplicateInsertionProbe);
